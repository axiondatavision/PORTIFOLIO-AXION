import { INSTAGRAM_URL, WHATSAPP_DISPLAY, buildWhatsAppUrl } from '../data/studioData';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#070708] py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-8 border-b border-zinc-800/80 pb-8 md:flex-row md:items-center">
          <div>
            <a
              href="#inicio"
              className="font-display text-lg font-bold tracking-tight text-[#F4F4F5] transition-colors hover:text-[#E5C158]"
            >
              AXION DATA VISION
            </a>
            <p className="mt-1.5 text-sm text-zinc-400">
              Onde a sua marca ganha vida online. Criação de sites para todo o Brasil.
            </p>
          </div>

          <nav aria-label="Links do rodapé" className="flex flex-wrap items-center gap-6 text-sm text-zinc-400">
            <a href="#sobre" className="transition-colors hover:text-[#E5C158]">
              Sobre
            </a>
            <a href="#servicos" className="transition-colors hover:text-[#E5C158]">
              Serviços
            </a>
            <a href="#portfolio" className="transition-colors hover:text-[#E5C158]">
              Portfólio
            </a>
            <a href="#depoimentos" className="transition-colors hover:text-[#E5C158]">
              Depoimentos
            </a>
            <a href="#contato" className="transition-colors hover:text-[#E5C158]">
              Contato
            </a>
          </nav>
        </div>

        <div className="mt-8 flex flex-col justify-between gap-4 text-xs text-zinc-500 sm:flex-row sm:items-center">
          <p>
            © {currentYear} AXION DATA VISION. Todos os direitos reservados.
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="text-zinc-400 transition-colors hover:text-[#E5C158] tabular-nums"
            >
              WhatsApp: {WHATSAPP_DISPLAY}
            </a>
            <span aria-hidden="true">·</span>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-zinc-400 transition-colors hover:text-[#E5C158]"
            >
              Instagram @axiondatavision
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

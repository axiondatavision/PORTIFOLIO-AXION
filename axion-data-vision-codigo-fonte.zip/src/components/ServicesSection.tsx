import { ArrowUpRight, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { SERVICES, buildWhatsAppUrl } from '../data/studioData';

export function ServicesSection() {
  return (
    <section id="servicos" className="border-b border-zinc-800/80 bg-[#070708] py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
              Serviços · Criação de Sites
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] text-balance sm:text-4xl">
              Sites desenvolvidos para transformar atenção em faturamento.
            </h2>
          </div>

          <a
            href={buildWhatsAppUrl(
              'Olá! Gostaria de entender qual modelo de site ideal para aumentar as vendas da minha empresa.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-5 py-2.5 text-sm font-semibold text-[#070708] transition-colors duration-150 hover:bg-[#E5C158] whitespace-nowrap shrink-0 self-start lg:self-auto"
          >
            <span>Solicitar orçamento no WhatsApp</span>
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>

        {/* Grid Bento Assimétrico */}
        <div className="mt-12 grid grid-cols-1 gap-5 lg:grid-cols-3">
          {SERVICES.map((service, index) => {
            const isWide = index === 0 || index === 3;
            return (
              <motion.article
                key={service.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.4,
                  delay: index * 0.06,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`flex flex-col justify-between rounded-2xl border border-zinc-800/90 bg-[#111114] p-6 transition-colors duration-150 hover:border-[#D4AF37]/40 sm:p-8 ${
                  isWide ? 'lg:col-span-2' : 'lg:col-span-1'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-4">
                    <span className="font-display text-sm font-semibold text-[#E5C158] tabular-nums">
                      {service.number}
                    </span>
                    <span className="text-xs text-zinc-400">Entrega no mesmo dia</span>
                  </div>

                  <h3 className="mt-4 font-display text-xl font-bold tracking-tight text-[#F4F4F5] sm:text-2xl">
                    {service.title}
                  </h3>

                  <p className="mt-2 text-sm font-medium text-[#E5C158]">{service.subtitle}</p>

                  <p className="mt-4 max-w-2xl text-sm leading-relaxed text-zinc-300 sm:text-base">
                    {service.description}
                  </p>
                </div>

                <ul className="mt-6 space-y-2.5 border-t border-zinc-800/80 pt-5">
                  {service.deliverables.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm text-zinc-300">
                      <Check
                        className="mt-0.5 h-4 w-4 shrink-0 text-[#E5C158]"
                        aria-hidden="true"
                      />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

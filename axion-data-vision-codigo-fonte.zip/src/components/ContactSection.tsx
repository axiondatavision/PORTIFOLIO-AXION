import { FormEvent, useState } from 'react';
import { ArrowUpRight, CheckCircle2, Instagram, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import {
  INSTAGRAM_URL,
  WHATSAPP_DISPLAY,
  buildWhatsAppUrl,
} from '../data/studioData';

interface FormState {
  name: string;
  company: string;
  phone: string;
  goal: string;
  message: string;
}

interface FormErrors {
  name?: string;
  company?: string;
  phone?: string;
}

const INITIAL_STATE: FormState = {
  name: '',
  company: '',
  phone: '',
  goal: 'Site institucional para aumentar faturamento',
  message: '',
};

const SITE_GOALS = [
  'Site institucional para aumentar faturamento',
  'Página de vendas de alta conversão',
  'Portfólio profissional ou catálogo comercial',
  'Reformulação urgente com entrega no mesmo dia',
];

export function ContactSection() {
  const [form, setForm] = useState<FormState>(INITIAL_STATE);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (form.name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome para personalizarmos o atendimento.';
    }
    if (form.company.trim().length < 2) {
      nextErrors.company = 'Informe o nome da sua empresa ou segmento.';
    }
    const digitsOnly = form.phone.replace(/\D/g, '');
    if (digitsOnly.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp válido com DDD (ex: 61 99839-7871).';
    }
    return nextErrors;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    const formattedMessage = [
      `Olá, AXION DATA VISION! Gostaria de solicitar um orçamento no WhatsApp.`,
      ``,
      `*Nome:* ${form.name.trim()}`,
      `*Empresa / Segmento:* ${form.company.trim()}`,
      `*WhatsApp:* ${form.phone.trim()}`,
      `*Objetivo:* ${form.goal}`,
      form.message.trim() ? `*Detalhes do projeto:* ${form.message.trim()}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    const whatsappLink = buildWhatsAppUrl(formattedMessage);
    setSubmittedUrl(whatsappLink);
  };

  const handleReset = () => {
    setForm(INITIAL_STATE);
    setErrors({});
    setSubmittedUrl(null);
  };

  return (
    <section id="contato" className="border-b border-zinc-800/80 bg-[#0A0A0C] py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Coluna Esquerda: Argumento de conversão + canais diretos */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
                Contato · Orçamento rápido
              </p>
              <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] text-balance sm:text-4xl">
                Pronto para colocar o site da sua empresa no ar ainda hoje?
              </h2>
              <p className="mt-4 text-base leading-relaxed text-zinc-300">
                Preencha os dados ao lado para montar seu briefing ou chame diretamente no
                WhatsApp. Atendemos empresas de todo o Brasil com resposta rápida e entrega no mesmo
                dia.
              </p>

              <div className="mt-8 space-y-4 border-t border-zinc-800/80 pt-7">
                <a
                  href={buildWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between rounded-xl border border-zinc-800 bg-[#111114] p-4 transition-colors hover:border-[#D4AF37]/60"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#D4AF37]/15 text-[#E5C158]">
                      <MessageCircle className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-xs text-zinc-400">WhatsApp comercial</p>
                      <p className="font-display text-sm font-bold text-[#F4F4F5] tabular-nums">
                        {WHATSAPP_DISPLAY}
                      </p>
                    </div>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-[#E5C158]" aria-hidden="true" />
                </a>

                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between rounded-xl border border-zinc-800 bg-[#111114] p-4 transition-colors hover:border-[#D4AF37]/60"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#D4AF37]/15 text-[#E5C158]">
                      <Instagram className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-xs text-zinc-400">Instagram oficial</p>
                      <p className="font-display text-sm font-bold text-[#F4F4F5]">
                        @axiondatavision
                      </p>
                    </div>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-[#E5C158]" aria-hidden="true" />
                </a>
              </div>
            </div>
          </motion.div>

          {/* Coluna Direita: Formulário com validação + redirecionamento para WhatsApp */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="rounded-2xl border border-zinc-800 bg-[#111114] p-6 sm:p-8">
              {submittedUrl ? (
                <div className="py-6 text-left">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#D4AF37]/15 text-[#E5C158]">
                    <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 font-display text-2xl font-bold text-[#F4F4F5]">
                    Briefing pronto para envio no WhatsApp
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-zinc-300">
                    Organizamos as informações da sua empresa (<strong className="text-[#F4F4F5]">{form.company}</strong>).
                    Clique no botão abaixo para abrir a conversa com nossa equipe e receber seu
                    orçamento na hora.
                  </p>

                  <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
                    <a
                      href={submittedUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-6 py-3 text-sm font-semibold text-[#070708] transition-colors hover:bg-[#E5C158] whitespace-nowrap shrink-0"
                    >
                      <span>Solicitar orçamento no WhatsApp</span>
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </a>

                    <button
                      type="button"
                      onClick={handleReset}
                      className="inline-flex min-h-[48px] items-center justify-center rounded-lg border border-zinc-700 px-5 py-3 text-sm font-medium text-zinc-200 transition-colors hover:border-zinc-500 hover:text-white"
                    >
                      Editar informações
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-xs font-medium text-zinc-300"
                      >
                        Seu nome *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        autoComplete="name"
                        value={form.name}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, name: e.target.value }));
                          if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                        }}
                        placeholder="Ex: João Mendes"
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby={errors.name ? 'contact-name-error' : undefined}
                        className="mt-2 w-full min-h-[44px] rounded-lg border border-zinc-800 bg-[#070708] px-4 py-2.5 text-sm text-[#F4F4F5] placeholder:text-zinc-500 transition-colors focus:border-[#D4AF37] focus:outline-none"
                      />
                      {errors.name && (
                        <p id="contact-name-error" className="mt-1.5 text-xs text-amber-300">
                          {errors.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-company"
                        className="block text-xs font-medium text-zinc-300"
                      >
                        Empresa ou segmento *
                      </label>
                      <input
                        id="contact-company"
                        type="text"
                        required
                        autoComplete="organization"
                        value={form.company}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, company: e.target.value }));
                          if (errors.company)
                            setErrors((prev) => ({ ...prev, company: undefined }));
                        }}
                        placeholder="Ex: Clínica Odontológica Prime"
                        aria-invalid={Boolean(errors.company)}
                        aria-describedby={errors.company ? 'contact-company-error' : undefined}
                        className="mt-2 w-full min-h-[44px] rounded-lg border border-zinc-800 bg-[#070708] px-4 py-2.5 text-sm text-[#F4F4F5] placeholder:text-zinc-500 transition-colors focus:border-[#D4AF37] focus:outline-none"
                      />
                      {errors.company && (
                        <p id="contact-company-error" className="mt-1.5 text-xs text-amber-300">
                          {errors.company}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-phone"
                        className="block text-xs font-medium text-zinc-300"
                      >
                        Seu WhatsApp com DDD *
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        autoComplete="tel"
                        value={form.phone}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, phone: e.target.value }));
                          if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                        }}
                        placeholder="(61) 99999-9999"
                        aria-invalid={Boolean(errors.phone)}
                        aria-describedby={errors.phone ? 'contact-phone-error' : undefined}
                        className="mt-2 w-full min-h-[44px] rounded-lg border border-zinc-800 bg-[#070708] px-4 py-2.5 text-sm text-[#F4F4F5] placeholder:text-zinc-500 transition-colors focus:border-[#D4AF37] focus:outline-none"
                      />
                      {errors.phone && (
                        <p id="contact-phone-error" className="mt-1.5 text-xs text-amber-300">
                          {errors.phone}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-goal"
                        className="block text-xs font-medium text-zinc-300"
                      >
                        O que você precisa?
                      </label>
                      <select
                        id="contact-goal"
                        value={form.goal}
                        onChange={(e) => setForm((prev) => ({ ...prev, goal: e.target.value }))}
                        className="mt-2 w-full min-h-[44px] rounded-lg border border-zinc-800 bg-[#070708] px-4 py-2.5 text-sm text-[#F4F4F5] transition-colors focus:border-[#D4AF37] focus:outline-none"
                      >
                        {SITE_GOALS.map((goal) => (
                          <option key={goal} value={goal}>
                            {goal}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-message"
                      className="block text-xs font-medium text-zinc-300"
                    >
                      Conte brevemente sobre o seu projeto (opcional)
                    </label>
                    <textarea
                      id="contact-message"
                      rows={3}
                      value={form.message}
                      onChange={(e) => setForm((prev) => ({ ...prev, message: e.target.value }))}
                      placeholder="Ex: Quero um site moderno para captar clientes pelo Google Ads e Instagram."
                      className="mt-2 w-full rounded-lg border border-zinc-800 bg-[#070708] px-4 py-3 text-sm text-[#F4F4F5] placeholder:text-zinc-500 transition-colors focus:border-[#D4AF37] focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:items-center sm:justify-between">
                    <p className="text-xs text-zinc-400">
                      Entrega no mesmo dia · Atendimento em todo o Brasil
                    </p>
                    <button
                      type="submit"
                      className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-6 py-3 text-sm font-semibold text-[#070708] transition-colors duration-150 hover:bg-[#E5C158] whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <span>Solicitar orçamento no WhatsApp</span>
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

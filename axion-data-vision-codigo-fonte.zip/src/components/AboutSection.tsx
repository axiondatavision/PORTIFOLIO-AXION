import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl } from '../data/studioData';
import { ResilientImage } from './ResilientImage';
import aboutWorkspaceImg from '../assets/images/about_axion_workspace_1794743954251.jpg';

export function AboutSection() {
  return (
    <section id="sobre" className="border-b border-zinc-800/80 bg-[#0A0A0C] py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Fotografia do estúdio */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="relative h-full min-h-[280px] overflow-hidden rounded-2xl border border-zinc-800 bg-[#111114]">
              <ResilientImage
                src={aboutWorkspaceImg}
                alt="Mesa de criação da AXION DATA VISION com iluminação dourada e código de site em desenvolvimento"
                fallbackTitle="Bastidores AXION DATA VISION"
                className="h-full w-full object-cover lg:h-full"
              />
            </div>
          </motion.div>

          {/* História autêntica e posicionamento comercial */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-7"
          >
            <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
              Sobre o estúdio · História e propósito
            </p>

            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] text-balance sm:text-4xl">
              De uma paixão por criar interfaces a mais de 50 marcas posicionadas no Brasil.
            </h2>

            <div className="mt-6 space-y-4 text-base leading-relaxed text-zinc-300">
              <p>
                Sempre gostei muito de criar sites e percebi que poderia transformar essa habilidade
                em um negócio de resultado real para empresas brasileiras. Há 3 meses comecei a
                atender comercialmente e, desde então, já são mais de 50 clientes atendidos em
                diversos segmentos.
              </p>
              <p>
                Na <strong className="font-semibold text-[#F4F4F5]">AXION DATA VISION</strong>, cada
                projeto nasce com uma única prioridade: fazer sua empresa vender mais. Eliminamos a
                espera de semanas das agências tradicionais com um processo enxuto que garante{' '}
                <strong className="font-semibold text-[#E5C158]">entrega no mesmo dia</strong>,
                sem abrir mão de design sofisticado e textos pensados para conversão.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-4 border-t border-zinc-800/80 pt-7 sm:grid-cols-3">
              <div>
                <p className="font-display text-lg font-bold text-[#F4F4F5] tabular-nums">
                  +50 projetos
                </p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Sites entregues nos primeiros 3 meses de operação.
                </p>
              </div>
              <div>
                <p className="font-display text-lg font-bold text-[#F4F4F5]">Mesmo dia</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Agilidade máxima para sua campanha entrar no ar hoje.
                </p>
              </div>
              <div>
                <p className="font-display text-lg font-bold text-[#F4F4F5]">Todo o Brasil</p>
                <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                  Atendimento direto e personalizado via WhatsApp.
                </p>
              </div>
            </div>

            <div className="mt-8">
              <a
                href={buildWhatsAppUrl(
                  'Olá! Li sobre a história da AXION DATA VISION e quero solicitar um orçamento para minha empresa.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#D4AF37] px-5 py-2.5 text-sm font-semibold text-[#070708] transition-colors duration-150 hover:bg-[#E5C158] whitespace-nowrap shrink-0"
              >
                <span>Solicitar orçamento no WhatsApp</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

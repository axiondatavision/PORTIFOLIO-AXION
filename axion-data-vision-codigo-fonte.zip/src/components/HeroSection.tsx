import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { HERO_METRICS, buildWhatsAppUrl } from '../data/studioData';
import { ResilientImage } from './ResilientImage';
import heroStudioImg from '../assets/images/hero_axion_studio_1794743954158.jpg';

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative border-b border-zinc-800/80 bg-[#070708] pt-10 pb-14 sm:pt-14 sm:pb-20 lg:pt-20 lg:pb-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Coluna Esquerda: Hierarquia tipográfica + CTA principal */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-6"
          >
            <div>
              <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
                Criação de Sites de Alta Conversão · Atendimento em todo o Brasil
              </p>

              <h1
                className="mt-4 font-display font-bold tracking-tight text-[#F4F4F5] text-balance"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.75rem)', lineHeight: 1.06 }}
              >
                Onde a sua marca ganha vida online.
              </h1>

              <p className="mt-6 max-w-xl text-base leading-relaxed text-zinc-300 sm:text-lg">
                Transformamos a presença digital da sua empresa em uma máquina de vendas com{' '}
                <strong className="font-semibold text-[#F4F4F5]">entrega no mesmo dia</strong>. Sites
                modernos, rápidos no celular e estruturados para levar clientes prontos para fechar no
                seu WhatsApp.
              </p>
            </div>

            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-6 py-3 text-sm font-semibold text-[#070708] transition-all duration-150 hover:bg-[#E5C158] whitespace-nowrap shrink-0"
              >
                <span>Solicitar orçamento no WhatsApp</span>
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>

              <a
                href="#portfolio"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg border border-zinc-800 bg-[#111114] px-5 py-3 text-sm font-medium text-zinc-200 transition-colors duration-150 hover:border-[#D4AF37]/50 hover:text-[#E5C158] whitespace-nowrap shrink-0"
              >
                <span>Ver projetos entregues</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Coluna Direita: Imagem editorial 16:9 com mesma altura */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="relative h-full min-h-[260px] overflow-hidden rounded-2xl border border-zinc-800 bg-[#111114] sm:min-h-[340px]">
              <ResilientImage
                src={heroStudioImg}
                alt="Estúdio AXION DATA VISION com estação de criação de sites em preto e iluminação dourada"
                fallbackTitle="AXION DATA VISION"
                loading="eager"
                className="h-full w-full object-cover lg:h-full"
              />
              <div
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#070708]/85 via-[#070708]/20 to-transparent"
                aria-hidden="true"
              />
              <div className="absolute right-0 bottom-0 left-0 p-5 sm:p-6">
                <p className="text-xs font-medium text-[#E5C158]">
                  Estúdio Digital · AXION DATA VISION
                </p>
                <p className="mt-1 text-sm font-medium text-zinc-100">
                  Design minimalista em alto contraste construído para gerar faturamento real.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Faixa de métricas em largura total abaixo do Hero */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
          className="mt-12 grid grid-cols-2 gap-4 border-t border-zinc-800/80 pt-10 sm:gap-6 lg:grid-cols-4"
        >
          {HERO_METRICS.map((metric) => (
            <div
              key={metric.label}
              className="rounded-xl border border-zinc-800/80 bg-[#111114] p-5"
            >
              <p className="font-display text-2xl font-bold tracking-tight text-[#E5C158] tabular-nums sm:text-3xl">
                {metric.value}
              </p>
              <p className="mt-1.5 text-sm font-semibold text-[#F4F4F5]">{metric.label}</p>
              <p className="mt-0.5 text-xs text-zinc-400">{metric.detail}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

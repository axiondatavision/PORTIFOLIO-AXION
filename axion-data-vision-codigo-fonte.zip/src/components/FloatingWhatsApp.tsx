import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl } from '../data/studioData';

export function FloatingWhatsApp() {
  return (
    <motion.a
      href={buildWhatsAppUrl()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento no WhatsApp"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.25, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      className="fixed right-4 bottom-4 z-40 inline-flex h-12 items-center justify-center gap-2 rounded-full border border-[#F3D37A]/50 bg-[#D4AF37] px-3.5 text-[#070708] shadow-lg transition-colors duration-150 hover:bg-[#E5C158] sm:right-6 sm:bottom-6 sm:h-13 sm:px-5"
    >
      <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
      <span className="hidden text-xs font-semibold whitespace-nowrap sm:inline">
        Solicitar orçamento no WhatsApp
      </span>
    </motion.a>
  );
}

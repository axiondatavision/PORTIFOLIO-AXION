import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { TESTIMONIALS, buildWhatsAppUrl } from '../data/studioData';

export function TestimonialsSection() {
  return (
    <section
      id="depoimentos"
      className="border-b border-zinc-800/80 bg-[#070708] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
              Depoimentos · Resultados comprovados
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] text-balance sm:text-4xl">
              O que dizem empresários que já colocaram sua marca no ar com a gente.
            </h2>
          </div>

          <a
            href={buildWhatsAppUrl(
              'Olá! Vi os depoimentos de clientes no site e quero solicitar um orçamento para minha empresa.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-5 py-2.5 text-sm font-semibold text-[#070708] transition-colors duration-150 hover:bg-[#E5C158] whitespace-nowrap shrink-0 self-start lg:self-auto"
          >
            <span>Solicitar orçamento no WhatsApp</span>
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((item, index) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.4,
                delay: index * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="flex flex-col justify-between rounded-2xl border border-zinc-800/90 bg-[#111114] p-6 sm:p-7"
            >
              <div>
                <p className="font-display text-xs font-semibold tracking-wide text-[#E5C158] tabular-nums">
                  {item.outcome}
                </p>

                <p className="mt-4 text-sm leading-relaxed text-zinc-200 sm:text-base">
                  &ldquo;{item.quote}&rdquo;
                </p>
              </div>

              <footer className="mt-6 border-t border-zinc-800/80 pt-5">
                <p className="font-display text-sm font-bold text-[#F4F4F5]">{item.name}</p>
                <p className="mt-0.5 text-xs text-zinc-400">
                  {item.role} · {item.company}
                </p>
                <p className="mt-0.5 text-xs text-zinc-500">{item.location}</p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

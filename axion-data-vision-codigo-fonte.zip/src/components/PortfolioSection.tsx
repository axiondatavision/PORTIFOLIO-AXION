import { useEffect, useState } from 'react';
import { ArrowUpRight, Maximize2, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  PORTFOLIO_PROJECTS,
  PortfolioProject,
  buildWhatsAppUrl,
} from '../data/studioData';
import { ResilientImage } from './ResilientImage';

const CATEGORIES = [
  'Todos',
  'Saúde & Estética',
  'Consultoria & Finanças',
  'Imobiliário',
] as const;

type FilterCategory = (typeof CATEGORIES)[number];

export function PortfolioSection() {
  const [activeCategory, setActiveCategory] = useState<FilterCategory>('Todos');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const filteredProjects =
    activeCategory === 'Todos'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((project) => project.category === activeCategory);

  useEffect(() => {
    if (!selectedProject) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedProject]);

  return (
    <section id="portfolio" className="border-b border-zinc-800/80 bg-[#0A0A0C] py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-wide text-[#E5C158] sm:text-sm">
              Portfólio · Projetos selecionados
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] text-balance sm:text-4xl">
              Projetos entregues com foco em posicionamento e vendas.
            </h2>
          </div>

          {/* Controles interativos de filtro */}
          <div
            role="tablist"
            aria-label="Filtrar projetos por segmento"
            className="flex flex-wrap items-center gap-1.5 rounded-xl border border-zinc-800 bg-[#111114] p-1.5"
          >
            {CATEGORIES.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(category)}
                  className={`min-h-[38px] rounded-lg px-3.5 py-1.5 text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-[#D4AF37] font-semibold text-[#070708]'
                      : 'text-zinc-300 hover:bg-zinc-900 hover:text-[#F4F4F5]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Grid Bento de Projetos */}
        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {filteredProjects.map((project, index) => {
            const isLeadCard = activeCategory === 'Todos' && index === 0;
            return (
              <motion.article
                key={project.id}
                layout
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className={`group flex flex-col overflow-hidden rounded-2xl border border-zinc-800/90 bg-[#111114] transition-colors duration-150 hover:border-[#D4AF37]/50 ${
                  isLeadCard ? 'lg:col-span-2 lg:grid lg:grid-cols-12' : ''
                }`}
              >
                <div
                  className={`relative overflow-hidden bg-[#070708] ${
                    isLeadCard ? 'aspect-[4/3] lg:col-span-7 lg:aspect-auto lg:h-full' : 'aspect-[4/3]'
                  }`}
                >
                  <ResilientImage
                    src={project.image}
                    alt={project.imageAlt}
                    fallbackTitle={project.title}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    aria-label={`Ampliar detalhes do projeto ${project.title}`}
                    className="absolute right-4 bottom-4 inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-zinc-700/80 bg-[#070708]/85 px-3.5 py-2 text-xs font-medium text-zinc-100 backdrop-blur-sm transition-colors hover:border-[#D4AF37] hover:text-[#E5C158]"
                  >
                    <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Ver detalhes</span>
                  </button>
                </div>

                <div
                  className={`flex flex-1 flex-col justify-between p-6 sm:p-8 ${
                    isLeadCard ? 'lg:col-span-5' : ''
                  }`}
                >
                  <div>
                    {/* Metadados sem pílulas, com separadores tipográficos */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                      <span>{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.deliveryTime}</span>
                    </div>

                    <h3 className="mt-3 font-display text-xl font-bold tracking-tight text-[#F4F4F5] sm:text-2xl">
                      {project.title}
                    </h3>

                    <p className="mt-2 font-display text-sm font-semibold text-[#E5C158] tabular-nums">
                      {project.metric}
                    </p>

                    <p className="mt-4 text-sm leading-relaxed text-zinc-300">
                      {project.summary}
                    </p>
                  </div>

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-zinc-800/80 pt-5">
                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="min-h-[40px] text-xs font-semibold text-zinc-200 underline-offset-4 transition-colors hover:text-[#E5C158] hover:underline"
                    >
                      Ler estudo do projeto
                    </button>

                    <a
                      href={buildWhatsAppUrl(project.whatsappContext)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[40px] items-center gap-1.5 text-xs font-semibold text-[#E5C158] transition-colors hover:text-[#F3D37A] whitespace-nowrap shrink-0"
                    >
                      <span>Quero um site assim</span>
                      <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Modal / Lightbox de Detalhes do Projeto */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="project-modal-title"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 10 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(event) => event.stopPropagation()}
              className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-zinc-800 bg-[#111114]"
            >
              <div className="relative aspect-[16/10] w-full bg-[#070708]">
                <ResilientImage
                  src={selectedProject.image}
                  alt={selectedProject.imageAlt}
                  fallbackTitle={selectedProject.title}
                  className="h-full w-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  aria-label="Fechar detalhes do projeto"
                  className="absolute top-4 right-4 flex h-11 w-11 items-center justify-center rounded-lg border border-zinc-700 bg-[#070708]/90 text-zinc-100 transition-colors hover:border-[#D4AF37] hover:text-[#E5C158]"
                >
                  <X className="h-5 w-5" aria-hidden="true" />
                </button>
              </div>

              <div className="p-6 sm:p-8">
                <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                  <span>{selectedProject.client}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.deliveryTime}</span>
                </div>

                <h3
                  id="project-modal-title"
                  className="mt-2 font-display text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
                >
                  {selectedProject.title}
                </h3>

                <p className="mt-2 font-display text-sm font-semibold text-[#E5C158] tabular-nums">
                  Resultado alcançado: {selectedProject.metric}
                </p>

                <div className="mt-6 grid grid-cols-1 gap-6 border-t border-zinc-800 pt-6 sm:grid-cols-2">
                  <div>
                    <h4 className="text-xs font-semibold tracking-wide text-zinc-400">
                      Desafio da empresa
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-zinc-300">
                      {selectedProject.challenge}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold tracking-wide text-zinc-400">
                      Solução entregue
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-zinc-300">
                      {selectedProject.solution}
                    </p>
                  </div>
                </div>

                <div className="mt-8 flex flex-col gap-3 border-t border-zinc-800 pt-6 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-xs text-zinc-400">
                    Quer um site com este nível de acabamento no ar ainda hoje?
                  </p>
                  <a
                    href={buildWhatsAppUrl(selectedProject.whatsappContext)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#D4AF37] px-5 py-2.5 text-sm font-semibold text-[#070708] transition-colors hover:bg-[#E5C158] whitespace-nowrap shrink-0"
                  >
                    <span>Solicitar orçamento no WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

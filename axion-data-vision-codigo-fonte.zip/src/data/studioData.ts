import clinicaAuroraImg from '../assets/images/project_clinica_prime_1794743954369.jpg';
import axonConsultoriaImg from '../assets/images/project_consultoria_aura_1794743955153.jpg';
import altoBrasilImg from '../assets/images/project_imobiliaria_lumiere_1794743954909.jpg';

export const WHATSAPP_NUMBER = '5561998397871';
export const WHATSAPP_DISPLAY = '(61) 99839-7871';
export const INSTAGRAM_URL = 'https://www.instagram.com/axiondatavision/';

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMessage =
    'Olá! Vim pelo site da AXION DATA VISION e gostaria de solicitar um orçamento para criação de site com entrega no mesmo dia.';
  const text = encodeURIComponent(customMessage || defaultMessage);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  featured?: boolean;
}

export interface PortfolioProject {
  id: string;
  title: string;
  client: string;
  category: 'Saúde & Estética' | 'Consultoria & Finanças' | 'Imobiliário';
  deliveryTime: string;
  metric: string;
  summary: string;
  challenge: string;
  solution: string;
  image: string;
  imageAlt: string;
  whatsappContext: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  location: string;
  outcome: string;
  quote: string;
}

export const HERO_METRICS = [
  {
    value: '+50',
    label: 'Clientes atendidos',
    detail: 'Empresas de todo o Brasil',
  },
  {
    value: 'Mesmo dia',
    label: 'Entrega ágil',
    detail: 'Do briefing ao site no ar',
  },
  {
    value: '3 meses',
    label: 'Trajetória acelerada',
    detail: 'Foco total em conversão',
  },
  {
    value: '100%',
    label: 'Sob medida',
    detail: 'Design exclusivo para vendas',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'sites-alta-conversao',
    number: '01.',
    title: 'Sites e Páginas de Alta Conversão',
    subtitle: 'Estrutura pensada para transformar visitantes em pedidos no WhatsApp',
    description:
      'Desenvolvemos páginas estratégicas com copywriting persuasivo, carregamento instantâneo no celular e botões de contato posicionados nos pontos exatos de decisão do seu cliente.',
    deliverables: [
      'Design exclusivo alinhado ao posicionamento da marca',
      'Integração direta com WhatsApp e formulários inteligentes',
      'Estrutura otimizada para tráfego pago e Google',
    ],
    featured: true,
  },
  {
    id: 'entrega-mesmo-dia',
    number: '02.',
    title: 'Entrega no Mesmo Dia',
    subtitle: 'Agilidade sem comprometer o acabamento profissional',
    description:
      'Sua empresa não pode esperar semanas para começar a faturar online. Alinhamos o conceito, desenvolvemos o layout completo e colocamos seu site no ar no mesmo dia.',
    deliverables: [
      'Fluxo direto sem burocracia',
      'Revisão em tempo real pelo WhatsApp',
      'Publicação rápida com domínio e SSL',
    ],
  },
  {
    id: 'sites-institucionais',
    number: '03.',
    title: 'Sites Institucionais de Autoridade',
    subtitle: 'Posicionamento sólido que justifica o valor do seu serviço',
    description:
      'Quando um cliente pesquisa sua empresa, o visual do seu site define a confiança na sua proposta. Criamos presenças digitais limpas que elevam sua percepção de valor.',
    deliverables: [
      'Hierarquia visual moderna e minimalista',
      'Seções de prova social, serviços e diferenciais',
      'Experiência fluida em smartphones e desktops',
    ],
  },
  {
    id: 'portfolios-catalogos',
    number: '04.',
    title: 'Portfólios e Vitrine Comercial',
    subtitle: 'Apresente seus projetos ou produtos com clareza e impacto',
    description:
      'Organizamos seus melhores trabalhos, serviços ou catálogo em uma interface direta ao ponto, facilitando que o cliente entenda seu diferencial e peça orçamento na hora.',
    deliverables: [
      'Galerias interativas com carregamento rápido',
      'Copywriting focado em benefícios reais',
      'Compatibilidade total com campanhas no Instagram',
    ],
  },
];

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'clinica-aurora',
    title: 'Aurora Medicina Estética',
    client: 'Clínica Aurora',
    category: 'Saúde & Estética',
    deliveryTime: 'Entregue no mesmo dia',
    metric: '+165% em agendamentos pelo WhatsApp',
    summary:
      'Reestruturação completa da presença digital para clínica de estética avançada, substituindo links dispersos por uma vitrine de alta conversão.',
    challenge:
      'A clínica investia em anúncios no Instagram, mas perdia pacientes porque enviava o tráfego para um perfil sem clareza de procedimentos nem chamada direta para agendamento.',
    solution:
      'Criamos uma página editorial escura com detalhes em dourado, apresentando os 4 tratamentos principais, depoimentos reais e botão direto de avaliação no WhatsApp.',
    image: clinicaAuroraImg,
    imageAlt: 'Notebook exibindo o site da Clínica Aurora em fundo escuro com tipografia dourada',
    whatsappContext:
      'Olá! Vi o projeto Aurora Medicina Estética no portfólio da AXION DATA VISION e quero solicitar um orçamento no mesmo estilo.',
  },
  {
    id: 'axon-consultoria',
    title: 'Axon Estratégia Financeira',
    client: 'Axon Partners',
    category: 'Consultoria & Finanças',
    deliveryTime: 'Entregue no mesmo dia',
    metric: '3,2x mais solicitações de diagnóstico empresarial',
    summary:
      'Site institucional e funil de captação B2B desenvolvido para consultoria financeira voltada a empresários e investidores.',
    challenge:
      'O antigo site tinha visual datado e não transmitia a segurança necessária para fechar contratos de ticket médio elevado.',
    solution:
      'Aplicamos uma arquitetura minimalista com alto contraste, métricas claras de atuação e formulário conectado diretamente ao WhatsApp comercial.',
    image: axonConsultoriaImg,
    imageAlt: 'Monitor widescreen exibindo plataforma corporativa de estratégia financeira em preto e dourado',
    whatsappContext:
      'Olá! Vi o projeto Axon Estratégia Financeira no portfólio da AXION DATA VISION e gostaria de solicitar um orçamento.',
  },
  {
    id: 'alto-brasil-imoveis',
    title: 'Alto Brasil Imóveis Exclusivos',
    client: 'Alto Brasil Incorporadora',
    category: 'Imobiliário',
    deliveryTime: 'Entregue no mesmo dia',
    metric: 'R$ 4,8M em atendimentos originados nos primeiros 45 dias',
    summary:
      'Vitrine imobiliária de alto padrão projetada para captar compradores qualificados em lançamentos residenciais.',
    challenge:
      'Corretores perdiam tempo respondendo curiosos sem filtro porque o portfólio antigo não apresentava os diferenciais nem a faixa de investimento.',
    solution:
      'Estruturamos uma galeria responsiva para celular e tablet com apresentação objetiva dos empreendimentos e qualificação imediata via WhatsApp.',
    image: altoBrasilImg,
    imageAlt: 'Tablet e notebook exibindo portal imobiliário de alto padrão em tema escuro e dourado',
    whatsappContext:
      'Olá! Vi o projeto Alto Brasil Imóveis no portfólio da AXION DATA VISION e quero solicitar um orçamento para meu negócio.',
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'depoimento-1',
    name: 'Mariana Vasconcelos',
    role: 'Sócia-diretora',
    company: 'Clínica Aurora Estética',
    location: 'Brasília, DF',
    outcome: '+165% em agendamentos no 1º mês',
    quote:
      'Antes dependíamos apenas de mensagens soltas no Instagram. Fechei o pedido pela manhã e no fim do dia o site já estava no ar rodando com nossos anúncios. Os clientes chegam muito mais decididos.',
  },
  {
    id: 'depoimento-2',
    name: 'Rafael Albuquerque',
    role: 'Consultor Sênior',
    company: 'Albuquerque & Prado Assessoria',
    location: 'São Paulo, SP',
    outcome: 'Ticket médio 40% maior após o novo site',
    quote:
      'A clareza visual em preto e dourado mudou na hora a percepção dos empresários que atendemos. Em poucas horas tivemos um site limpo, rápido no celular e focado em gerar reunião no WhatsApp.',
  },
  {
    id: 'depoimento-3',
    name: 'Camila Ferreira',
    role: 'Gestora Comercial',
    company: 'Alto Brasil Imóveis',
    location: 'Goiânia, GO',
    outcome: 'Site publicado no mesmo dia do briefing',
    quote:
      'Precisávamos lançar uma campanha urgente no mesmo dia. A AXION DATA VISION entregou tudo pronto, responsivo e com textos que realmente convencem o cliente a chamar nossa equipe.',
  },
];
